# PySpark Data Processing Lab 1

## Описание проекта
Репозиторий содержит лабораторную работу, посвящённую обработке больших данных с использованием Apache Spark и PySpark. В работе применяются различные методы загрузки, очистки, обработки и визуализации данных.

## Структура
- `data_processing_lab1.py`: основной скрипт обработки данных.
- `report.md`: отчёт о проделанной работе.
- `group_distribution.png`: итоговый график распределения.

## Запуск
```bash
spark-submit data_processing_lab1.py
```

## Требования
- Apache Spark
- PySpark
- Pandas
- Seaborn
- Matplotlib
