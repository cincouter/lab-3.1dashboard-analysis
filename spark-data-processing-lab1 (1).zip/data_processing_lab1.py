from pyspark.sql import SparkSession
from pyspark.sql.functions import col
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# 1. Инициализация Spark-сессии
spark = SparkSession.builder \
    .appName("PySpark Data Processing Lab1") \
    .getOrCreate()

# 2. Загрузка данных в DataFrame
file_path = "hdfs:///user5/sparkdir/your_data.csv"  # Заменить на актуальный путь

df = spark.read.option("header", True).csv(file_path)

# 3. Предварительная обработка данных
clean_df = df.dropna()
clean_df = clean_df.withColumn("column_name", col("column_name").cast("int"))  # Заменить column_name

# 4. Пример работы с RDD
# Преобразуем DataFrame в RDD и применим map и reduce
rdd = clean_df.select("column_name").rdd
values_rdd = rdd.map(lambda row: row[0])
sum_result = values_rdd.reduce(lambda x, y: x + y)
print(f"Сумма значений в column_name: {sum_result}")

# 5. Применение операций с DataFrame
agg_df = clean_df.groupBy("group_column").count()  # Заменить group_column

# 6. Использование Spark SQL
clean_df.createOrReplaceTempView("temp_table")
sql_result = spark.sql("SELECT group_column, COUNT(*) as count FROM temp_table GROUP BY group_column")

# 7. Визуализация результатов
pandas_df = sql_result.toPandas()

sns.set(style="whitegrid")
plt.figure(figsize=(10, 6))
sns.barplot(data=pandas_df, x="group_column", y="count")
plt.title("Распределение по группам")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("group_distribution.png")
plt.show()

# Завершение работы
spark.stop()
